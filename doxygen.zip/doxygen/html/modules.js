var modules =
[
    [ "actuators.cpp", "group___a_c_t_u_a_t_o_r_s.html", null ],
    [ "comm.cpp", "group___c_o_m_m.html", null ],
    [ "global_definitions.h", "group___g_l_o_b_a_l___d_e_f_i_n_i_t_i_o_n_s.html", null ],
    [ "rtos_tasks.cpp", "group___r_t_o_s___t_a_s_k_s.html", null ],
    [ "sensors.cpp", "group___s_e_n_s_o_r_s.html", null ],
    [ "main.cpp", "group___m_a_i_n.html", null ]
];