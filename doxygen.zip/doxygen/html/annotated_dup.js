var annotated_dup =
[
    [ "ADCSdata", "class_a_d_c_sdata.html", "class_a_d_c_sdata" ],
    [ "ADCSPhotodiodeArray", "class_a_d_c_s_photodiode_array.html", "class_a_d_c_s_photodiode_array" ],
    [ "DRV10970", "class_d_r_v10970.html", "class_d_r_v10970" ],
    [ "ICM_20948", "class_i_c_m__20948.html", null ],
    [ "ICM_20948_I2C", "class_i_c_m__20948___i2_c.html", null ],
    [ "ICM_20948_SPI", "class_i_c_m__20948___s_p_i.html", null ],
    [ "IMUdata", "struct_i_m_udata.html", null ],
    [ "INA209", "class_i_n_a209.html", null ],
    [ "INAdata", "struct_i_n_adata.html", null ],
    [ "PDdata", "union_p_ddata.html", null ],
    [ "TEScommand", "class_t_e_scommand.html", "class_t_e_scommand" ],
    [ "ZXMB5210", "class_z_x_m_b5210.html", "class_z_x_m_b5210" ]
];