var class_z_x_m_b5210 =
[
    [ "ZXMB5210", "class_z_x_m_b5210.html#a8f02ed24bcba43379b3db2de843d54ab", null ],
    [ "ZXMB5210", "class_z_x_m_b5210.html#a40a448e9084941428fd531cb01169bab", null ],
    [ "fwd", "class_z_x_m_b5210.html#abff0ca4d6dc356c5520ea07f6e21cf25", null ],
    [ "init", "class_z_x_m_b5210.html#a3783f776042c22329c80f9af1d663a1b", null ],
    [ "rev", "class_z_x_m_b5210.html#a86ffcf120d8688eeba56d0f1f7e55592", null ],
    [ "standby", "class_z_x_m_b5210.html#a3f0fc4a00437298dc33cd247f90ad1f2", null ],
    [ "stop", "class_z_x_m_b5210.html#a55710c417176726fe5c0e06b1f9035eb", null ]
];