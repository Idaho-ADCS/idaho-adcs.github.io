var searchData=
[
  ['global_5fdefinitions_2eh_0',['global_definitions.h',['../group___g_l_o_b_a_l___d_e_f_i_n_i_t_i_o_n_s.html',1,'']]]
];
