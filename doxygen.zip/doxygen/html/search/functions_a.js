var searchData=
[
  ['zxmb5210_0',['ZXMB5210',['../class_z_x_m_b5210.html#a8f02ed24bcba43379b3db2de843d54ab',1,'ZXMB5210::ZXMB5210(uint8_t fwd, uint8_t rev, uint8_t buck)'],['../class_z_x_m_b5210.html#a40a448e9084941428fd531cb01169bab',1,'ZXMB5210::ZXMB5210(uint8_t fwd, uint8_t rev)']]]
];
