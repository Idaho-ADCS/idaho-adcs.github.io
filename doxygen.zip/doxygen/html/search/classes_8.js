var searchData=
[
  ['semaphoredata_0',['SemaphoreData',['../struct_semaphore_data.html',1,'']]],
  ['streambufferdef_5ft_1',['StreamBufferDef_t',['../struct_stream_buffer_def__t.html',1,'']]]
];
