var searchData=
[
  ['send_0',['send',['../class_a_d_c_sdata.html#a14b1003def53221630951b6490f79aa4',1,'ADCSdata']]],
  ['sensors_2ecpp_1',['sensors.cpp',['../group___s_e_n_s_o_r_s.html',1,'']]],
  ['setimudata_2',['setIMUdata',['../class_a_d_c_sdata.html#a493f6065135876a0ad2b1e2ac29f3c6f',1,'ADCSdata']]],
  ['setinadata_3',['setINAdata',['../class_a_d_c_sdata.html#a3826b1c26e5a29f456d72a50553b8079',1,'ADCSdata']]],
  ['setstatus_4',['setStatus',['../class_a_d_c_sdata.html#abd6b345d3f48e6135b843aa1522800a2',1,'ADCSdata']]],
  ['single_20axis_20attitude_20determination_20and_20control_20system_20v1_2e0_5',['Single Axis Attitude Determination and Control System v1.0',['../index.html',1,'']]],
  ['sparkfun_20icm_2d20948_20arduino_20library_6',['SparkFun ICM-20948 Arduino Library',['../md_lib__i_c_m_20948__r_e_a_d_m_e.html',1,'']]],
  ['spindlefree_7',['spindleFree',['../class_d_r_v10970.html#ae0aacd1be4a470bda89a329e2fe506f5',1,'DRV10970']]],
  ['standby_8',['standby',['../class_z_x_m_b5210.html#a3f0fc4a00437298dc33cd247f90ad1f2',1,'ZXMB5210']]],
  ['stop_9',['stop',['../class_d_r_v10970.html#acf4dd99c81f38af600639e388330a65c',1,'DRV10970::stop()'],['../class_z_x_m_b5210.html#a55710c417176726fe5c0e06b1f9035eb',1,'ZXMB5210::stop()']]]
];
