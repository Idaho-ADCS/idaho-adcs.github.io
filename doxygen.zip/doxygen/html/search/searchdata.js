var indexSectionsWithContent =
{
  0: "acdfgilmprstz",
  1: "adiptz",
  2: "acdfgilrstz",
  3: "acgmrs",
  4: "adsz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Modules",
  4: "Pages"
};

