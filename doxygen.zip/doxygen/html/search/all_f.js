var searchData=
[
  ['ultasknotifytake_0',['ulTaskNotifyTake',['../group__ul_task_notify_take.html',1,'']]],
  ['uxqueuemessageswaiting_1',['uxQueueMessagesWaiting',['../group__ux_queue_messages_waiting.html',1,'']]],
  ['uxtaskgetnumberoftasks_2',['uxTaskGetNumberOfTasks',['../group__ux_task_get_number_of_tasks.html',1,'']]],
  ['uxtaskpriorityget_3',['uxTaskPriorityGet',['../group__ux_task_priority_get.html',1,'']]]
];
