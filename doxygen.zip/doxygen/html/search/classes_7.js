var searchData=
[
  ['queue_5fregistry_5fitem_0',['QUEUE_REGISTRY_ITEM',['../struct_q_u_e_u_e___r_e_g_i_s_t_r_y___i_t_e_m.html',1,'']]],
  ['queuedefinition_1',['QueueDefinition',['../struct_queue_definition.html',1,'']]],
  ['queuepointers_2',['QueuePointers',['../struct_queue_pointers.html',1,'']]]
];
