var searchData=
[
  ['semaphoredata_0',['SemaphoreData',['../struct_semaphore_data.html',1,'']]],
  ['send_1',['send',['../class_a_d_c_sdata.html#a14b1003def53221630951b6490f79aa4',1,'ADCSdata']]],
  ['sensors_2',['sensors',['../group___s_e_n_s_o_r_s.html',1,'']]],
  ['setimudata_3',['setIMUdata',['../class_a_d_c_sdata.html#a493f6065135876a0ad2b1e2ac29f3c6f',1,'ADCSdata']]],
  ['setinadata_4',['setINAdata',['../class_a_d_c_sdata.html#a3826b1c26e5a29f456d72a50553b8079',1,'ADCSdata']]],
  ['setstatus_5',['setStatus',['../class_a_d_c_sdata.html#abd6b345d3f48e6135b843aa1522800a2',1,'ADCSdata']]],
  ['sparkfun_20icm_2d20948_20arduino_20library_6',['SparkFun ICM-20948 Arduino Library',['../md_lib__i_c_m_20948__r_e_a_d_m_e.html',1,'']]],
  ['sparkfun_20license_20information_7',['SparkFun License Information',['../md_lib__i_c_m_20948__license.html',1,'']]],
  ['streambufferdef_5ft_8',['StreamBufferDef_t',['../struct_stream_buffer_def__t.html',1,'']]],
  ['subject_20of_20the_20issue_9',['Subject of the issue',['../md_lib__i_c_m_20948__i_s_s_u_e__t_e_m_p_l_a_t_e.html',1,'']]]
];
