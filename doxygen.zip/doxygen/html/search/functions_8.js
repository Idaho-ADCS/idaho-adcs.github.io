var searchData=
[
  ['send_0',['send',['../class_a_d_c_sdata.html#a14b1003def53221630951b6490f79aa4',1,'ADCSdata']]],
  ['setimudata_1',['setIMUdata',['../class_a_d_c_sdata.html#a493f6065135876a0ad2b1e2ac29f3c6f',1,'ADCSdata']]],
  ['setinadata_2',['setINAdata',['../class_a_d_c_sdata.html#a3826b1c26e5a29f456d72a50553b8079',1,'ADCSdata']]],
  ['setstatus_3',['setStatus',['../class_a_d_c_sdata.html#abd6b345d3f48e6135b843aa1522800a2',1,'ADCSdata']]],
  ['spindlefree_4',['spindleFree',['../class_d_r_v10970.html#ae0aacd1be4a470bda89a329e2fe506f5',1,'DRV10970']]],
  ['standby_5',['standby',['../class_z_x_m_b5210.html#a3f0fc4a00437298dc33cd247f90ad1f2',1,'ZXMB5210']]],
  ['stop_6',['stop',['../class_d_r_v10970.html#acf4dd99c81f38af600639e388330a65c',1,'DRV10970::stop()'],['../class_z_x_m_b5210.html#a55710c417176726fe5c0e06b1f9035eb',1,'ZXMB5210::stop()']]]
];
