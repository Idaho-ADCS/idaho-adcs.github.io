var class_d_r_v10970 =
[
    [ "DRV10970", "class_d_r_v10970.html#a17700b51ed2f1b69277142688f36fd9a", null ],
    [ "init", "class_d_r_v10970.html#a94545369358fac3d0937e8a93bf4d801", null ],
    [ "readRPM", "class_d_r_v10970.html#a2961358c65dde531f0391ef08ba0b0bc", null ],
    [ "run", "class_d_r_v10970.html#a0745bd2031275e70465e2590689ef68d", null ],
    [ "spindleFree", "class_d_r_v10970.html#ae0aacd1be4a470bda89a329e2fe506f5", null ],
    [ "stop", "class_d_r_v10970.html#acf4dd99c81f38af600639e388330a65c", null ]
];