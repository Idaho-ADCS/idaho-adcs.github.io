var class_a_d_c_s_photodiode_array =
[
    [ "init", "class_a_d_c_s_photodiode_array.html#a407ad628fbd11d0de665ba9241a12d41", null ],
    [ "read", "class_a_d_c_s_photodiode_array.html#aae14233b11ab2ac03c251bf6482c3259", null ]
];